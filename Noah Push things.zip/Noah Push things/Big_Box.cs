using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Big_Box : MonoBehaviour
{
    // Start is called before the first frame update
    Audio_Manager audman;
    void Start()
    {
        audman = FindObjectOfType<Audio_Manager>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("OOF");
        audman.Playsound8();
    }
   
    private void OnCollisionEnter2D(Collision2D collision)
    {
       // Debug.Log("OOF");

    }


}
