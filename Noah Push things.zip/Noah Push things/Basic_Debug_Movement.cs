using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Basic_Debug_Movement : MonoBehaviour
{
    // Start is called before the first frame update
    public bool DEBUG_WALK_ON = true;
    public bool walking = false;
    public bool A_down = false;
    public bool D_down = false;

    public SpriteRenderer mysprite;

    void Start()
    {
    
    }
    // Update is called once per frame
    void Update()
    {
        if (DEBUG_WALK_ON == true)
        {
            debugwalking();
        }
    }
    public void debugwalking()
    {
        if (Input.GetKeyDown("a"))
        {
            A_down = true;
        }
        if (Input.GetKeyUp("a"))
        {
            A_down = false;
        }
        if (Input.GetKeyDown("d"))
        {
            D_down = true;

        }
        if (Input.GetKeyUp("d"))
        {
            D_down = false;

        }
        if (A_down == true && D_down == false)
        {
            this.gameObject.transform.Translate(new Vector3(Time.deltaTime * -5, 0, 0));
            mysprite.flipX = true;
        }
        else if (A_down == false && D_down == true)
        {
            this.gameObject.transform.Translate(new Vector3(Time.deltaTime * 5, 0, 0));
            mysprite.flipX = false;
        }
        else
        { }
        if (A_down == true || D_down == true)
        {
            walking = true;
        }
        else
        {
            walking = false;
        }
    }
}
