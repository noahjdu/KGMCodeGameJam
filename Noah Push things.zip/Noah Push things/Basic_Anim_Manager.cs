using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Basic_Anim_Manager : MonoBehaviour
{
    // Start is called before the first frame update
    public SpriteRenderer sprite_render;

    public Basic_Debug_Movement DebugMove;
    public Animator anim; 


    public Audio_Manager audman;
    public ParticleSystem parti_system;

    // an int value that indicates what shape the character should be
    public int Shape = 0;
    //0: circle
    //1: Rectangle
    //2: Rhombus
    //3: Square
    //4: triangle
    public int Emotion = 0;
    //0: walking
    //1: Mad
    //2: OWO
    //3: Happy
    //4: Sad


    public List<Sprite> Circles =  new List<Sprite>();
    public List<Sprite> Rectangles = new List<Sprite>(); 
    public List<Sprite> Rhombus = new List<Sprite>();
    public List<Sprite> Square = new List<Sprite>();
    public List<Sprite> triangle = new List<Sprite>();


    void Start()
    {
        anim = GetComponent<Animator>();
        audman = FindObjectOfType<Audio_Manager>();
       // sprite_render = GetComponent<SpriteRenderer>();
    }


    public void walking_switch()
    {
        Emotion = 0;
        sprite_render.color = Color.white;
        change_emotion();

    }
    public void Mad_switch()
    {
        Emotion = 1;
        sprite_render.color = Color.red;
        change_emotion();

    }
    public void OWO_switch()
    {
        Emotion = 2;
        sprite_render.color = Color.cyan;
        change_emotion();

    }
    public void Happy_switch()
    {
        Emotion = 3;
        sprite_render.color = Color.yellow;
        change_emotion();


    }
    public void Sad_switch()
    {
        Emotion = 4;
        change_emotion();
        sprite_render.color = Color.blue;

    }


    private void Update()
    {
        if (Input.GetKeyDown("1"))
        {
            walking_switch();
            audman.Playsound6();
            parti_system.Play();

        }
        if (Input.GetKeyDown("2"))
        {
            Mad_switch();
            audman.Playsound7();
            parti_system.Play();

        }
        if (Input.GetKeyDown("3"))
        {
            OWO_switch();
            audman.Playsound6();
            parti_system.Play();

        }
        if (Input.GetKeyDown("4"))
        {
            Happy_switch();
            audman.Playsound7();
            parti_system.Play();
        }
        if (Input.GetKeyDown("5"))
        {
            Sad_switch();
            audman.Playsound6();
            parti_system.Play();


        }
        if (DebugMove.walking == true)
        { anim.SetBool("Walking", true);}
        else
        { anim.SetBool("Walking", false); }
        change_Shape();
    }

    // function to change sha
    public void change_Shape()
    {
        if (Input.GetKeyDown("6"))
        {
            Change_to_Circles();
            audman.Playsound4();

        }
        if (Input.GetKeyDown("7"))
        {
            Change_to_square();
            audman.Playsound4();

        }
        if (Input.GetKeyDown("8"))
        {
            Change_to_Rhombus();
            audman.Playsound4();

        }
        if (Input.GetKeyDown("9"))
        {
            Change_to_Square();
            audman.Playsound4();

        }
        if (Input.GetKeyDown("0"))
        {
            Change_to_Triangle();
            audman.Playsound4();
        }
    }
    public void change_emotion()
    {
        if (Shape == 0)
        {
            sprite_render.sprite = Circles[Emotion];
        }
        else if (Shape == 1)
        {
            sprite_render.sprite = Rectangles[Emotion];
        }
        else if (Shape == 2)
        {
            sprite_render.sprite = Rhombus[Emotion];
        }
        else if (Shape == 3)
        {
            sprite_render.sprite = Square[Emotion];
        }
        else if (Shape == 3)
        {
            sprite_render.sprite = triangle[Emotion];
        }
    }
    public void Change_to_Circles()
    {
        Shape = 0;
        //we could also use change emotion function here.
        sprite_render.sprite = Circles[Emotion];

    }
    public void Change_to_square()
    {
        Shape = 1;
        sprite_render.sprite = Rectangles[Emotion];

    }
    public void Change_to_Rhombus()
    {
        Shape = 2;
        sprite_render.sprite = Rhombus[Emotion];

    }
    public void Change_to_Square()
    {
        Shape = 3;
        sprite_render.sprite = Square[Emotion];

    }
    public void Change_to_Triangle()
    {
        Shape = 4;
        sprite_render.sprite = triangle[Emotion];

    }
}
